import type {Metadata} from 'next';
import AdminPanel from '@/components/admin-panel';
export const metadata:Metadata={title:'Portfolio Administration',robots:{index:false,follow:false}};
export default function Admin(){return <section className="container inner-page"><div className="page-intro"><span className="eyebrow accent">PRIVATE CONTENT MANAGEMENT</span><h1>Coursework administration</h1><p>Manage new learning achievements and control which records appear in the public portfolio. Access is enforced in the database using authentication and Row Level Security.</p></div><AdminPanel/></section>}

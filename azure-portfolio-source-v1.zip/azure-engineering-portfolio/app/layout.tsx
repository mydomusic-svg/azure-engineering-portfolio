import type {Metadata} from 'next';
import Navigation from '@/components/navigation';
import Footer from '@/components/footer';
import './globals.css';
export const metadata:Metadata={title:{default:'Myron Johnson | Azure Engineering Portfolio',template:'%s | Myron Johnson'},description:'Azure engineering projects, cloud infrastructure skills, and a verified Microsoft Learn coursework history.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body><Navigation/><main>{children}</main><Footer/></body></html>}

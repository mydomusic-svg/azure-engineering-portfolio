import Link from 'next/link';
export default function NotFound(){return <section className="container inner-page"><div className="page-intro"><span className="eyebrow accent">404</span><h1>Page not found</h1><p>The page you requested does not exist.</p><Link className="btn primary" href="/">Return home</Link></div></section>}

import type {Metadata} from 'next';
import ProjectCard from '@/components/project-card';
import {projects} from '@/lib/content';
export const metadata:Metadata={title:'Azure Projects'};
export default function Projects(){return <section className="container inner-page"><div className="page-intro"><span className="eyebrow accent">AZURE ENGINEERING WORKBENCH</span><h1>Projects & architecture</h1><p>Practical infrastructure projects spanning networking, identity, operations, and automation. These are <strong>planned labs</strong>; completed case studies will be labeled only after execution and testing.</p></div><div className="project-grid">{projects.map(p=><ProjectCard project={p} key={p.slug}/>)}</div><div className="notice"><strong>Proof over buzzwords.</strong> Each finished project will include implementation artifacts, validation evidence, lessons learned, and links to source code where appropriate.</div></section>}

import Link from 'next/link';
export default function Footer(){return <footer className="footer"><div className="container footer-inner"><span>© {new Date().getFullYear()} Myron Johnson · Azure Engineering Portfolio</span><div><Link href="/projects">Projects</Link><Link href="/learning">Learning</Link><Link href="/admin">Admin</Link></div></div></footer>}

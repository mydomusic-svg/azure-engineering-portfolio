'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Cloud, Menu, X, ExternalLink } from 'lucide-react';
import { useState } from 'react';
const links=[['/','Overview'],['/projects','Projects'],['/learning','Learning'],['/experience','Experience']];
export default function Navigation(){
 const path=usePathname(); const [open,setOpen]=useState(false);
 return <header className="site-header"><div className="container nav-wrap">
 <Link href="/" className="brand" onClick={()=>setOpen(false)} aria-label="Portfolio home"><span className="brand-icon"><Cloud size={22}/></span><span><strong>MYRON JOHNSON</strong><small>AZURE ENGINEERING</small></span></Link>
 <button className="mobile-toggle" aria-expanded={open} aria-label="Toggle navigation" onClick={()=>setOpen(!open)}>{open?<X/>:<Menu/>}</button>
 <nav className={open?'nav-links opened':'nav-links'} aria-label="Main navigation">{links.map(([href,label])=><Link key={href} className={path===href||href!=='/'&&path.startsWith(href)?'active':''} href={href} onClick={()=>setOpen(false)}>{label}</Link>)}<Link href="/admin" className="nav-admin" onClick={()=>setOpen(false)}>Admin <ExternalLink size={13}/></Link></nav>
 </div></header>;
}

import Link from 'next/link';
import {ArrowUpRight, Network, ShieldCheck, Activity, Terminal} from 'lucide-react';
import type {Project} from '@/lib/content';
const icons:{[key:string]:typeof Network}={network:Network,shield:ShieldCheck,activity:Activity,terminal:Terminal};
export default function ProjectCard({project}:{project:Project}){const Icon=icons[project.icon]||Network;return <Link className="project-card" href={`/projects/${project.slug}`}><div className="project-card-top"><span className="project-icon"><Icon size={23}/></span><span className={`status ${project.status==='Completed'?'completed':project.status==='In progress'?'progress':'planned'}`}>{project.status}</span></div><span className="eyebrow">{project.category}</span><h3>{project.title}</h3><p>{project.summary}</p><div className="tag-row">{project.services.slice(0,3).map(s=><span className="tag" key={s}>{s}</span>)}</div><span className="card-link">Explore case study <ArrowUpRight size={17}/></span></Link>}

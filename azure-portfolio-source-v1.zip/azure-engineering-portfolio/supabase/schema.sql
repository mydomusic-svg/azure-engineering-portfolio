-- Run in your own Supabase SQL Editor. The browser uses ONLY the public anon key.
-- Create the owner account manually via Supabase Authentication > Users.
-- Then insert that existing user's UUID into portfolio_admins in the SQL editor.
create extension if not exists pgcrypto;
create table if not exists public.portfolio_admins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);
create table if not exists public.coursework (
  id uuid primary key default gen_random_uuid(),
  title text not null check (char_length(title) between 1 and 180),
  category text not null check (char_length(category) between 1 and 100),
  provider text not null check (char_length(provider) between 1 and 100),
  description text not null default '' check (char_length(description) <= 1000),
  completed_on date,
  status text not null default 'Completed' check (status in ('Completed','In progress')),
  url text check (url is null or url ~ '^https://'),
  published boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists coursework_published_idx on public.coursework (published,completed_on desc);
alter table public.portfolio_admins enable row level security;
alter table public.coursework enable row level security;
revoke all on public.portfolio_admins from anon,authenticated;
revoke all on public.coursework from anon,authenticated;
grant select on public.portfolio_admins to authenticated;
grant select on public.coursework to anon,authenticated;
grant insert,update,delete on public.coursework to authenticated;
-- Allow admin to read only own membership. Membership insertion is dashboard/SQL only.
create policy "Admins can read own membership" on public.portfolio_admins for select to authenticated using (user_id = (select auth.uid()));
-- Public sees only published records; authenticated admins also see drafts.
create policy "Public can read published coursework" on public.coursework for select to anon,authenticated using (published = true);
create policy "Admin can read all coursework" on public.coursework for select to authenticated using (
  exists (select 1 from public.portfolio_admins where user_id = (select auth.uid()))
);
create policy "Admin can insert coursework" on public.coursework for insert to authenticated with check (
  exists (select 1 from public.portfolio_admins where user_id = (select auth.uid()))
);
create policy "Admin can update coursework" on public.coursework for update to authenticated
  using (exists (select 1 from public.portfolio_admins where user_id = (select auth.uid())))
  with check (exists (select 1 from public.portfolio_admins where user_id = (select auth.uid())));
create policy "Admin can delete coursework" on public.coursework for delete to authenticated using (
  exists (select 1 from public.portfolio_admins where user_id = (select auth.uid()))
);
-- Example to grant the owner access (replace UUID after creating auth user):
-- insert into public.portfolio_admins(user_id) values ('YOUR-AUTH-USER-UUID');
